using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;

public class DialogueGraphView : GraphView
{
    public readonly Vector2 defaultNodeSize = new Vector2(150,150);
    public DialogueGraphView()
    {
        styleSheets.Add(Resources.Load<StyleSheet>("NarrativeGraph"));
        SetupZoom(ContentZoomer.DefaultMinScale, ContentZoomer.DefaultMaxScale);

        this.AddManipulator(new ContentDragger());
        this.AddManipulator(new SelectionDragger());
        this.AddManipulator(new RectangleSelector());
        //this.AddManipulator(new FreehandSelector());

        var grid = new GridBackground();
        Insert(0, grid);
        grid.StretchToParentSize();
        AddElement(GenerateEntryPointNode());
    }

    public override List<Port> GetCompatiblePorts(Port startPort, NodeAdapter nodeAdapter)
    {
        var compatiblePorts = new List<Port>();

        ports.ForEach((port) =>
        {
            if (startPort != port && startPort.node != port.node)
                compatiblePorts.Add(port);
        });
        return compatiblePorts;
    }

    private Port GeneratePort(DialogueNode node, Direction portDirection, Port.Capacity capacity = Port.Capacity.Single)
    {
        // ��Ʈ Ÿ�� ���ϴ� ���� ��
        return node.InstantiatePort(Orientation.Horizontal, portDirection, capacity, typeof(float));
    }

    private DialogueNode GenerateEntryPointNode()
    {
        var node = new DialogueNode { title = "Start", GUID = Guid.NewGuid().ToString(), DialogueText = "ENTRYPOINT", EntryPoint = true };

        var generatedPort = GeneratePort(node, Direction.Output);
        generatedPort.portName = "Next";
        node.titleContainer.Add(generatedPort);

        node.RefreshExpandedState();
        node.RefreshPorts();


        node.SetPosition(new Rect(100, 200, 100, 150)); 
        return node;
    }

    public void CreateNode(string nodeName)
    {
        AddElement(CreateDialogueNode(nodeName));
    }


    public DialogueNode CreateDialogueNode(string nodeName)
    {
        var dialogNode = new DialogueNode { title = nodeName, DialogueText = nodeName, GUID = Guid.NewGuid().ToString() };

        var inputPort = GeneratePort(dialogNode, Direction.Input, Port.Capacity.Multi);
        inputPort.portName = "input";
        dialogNode.inputContainer.Add(inputPort);

        var button = new Button(() => { AddChoicePort(dialogNode); });
        button.text = "button";
        dialogNode.titleContainer.Add(button);

        var textField = new TextField(string.Empty);
        textField.RegisterValueChangedCallback(evt =>
        {
            dialogNode.DialogueText = evt.newValue;
            dialogNode.title = evt.newValue;
        });
        textField.SetValueWithoutNotify(dialogNode.title);
        dialogNode.mainContainer.Add(textField);

        dialogNode.RefreshExpandedState();
        dialogNode.RefreshPorts();
        dialogNode.SetPosition(new Rect(Vector2.zero, defaultNodeSize));

        return dialogNode;
    }

    public void AddChoicePort(DialogueNode dialogueNode, string overriddenPortName="")
    {
        var generatedPort = GeneratePort(dialogueNode, Direction.Output);

        var oldLable = generatedPort.contentContainer.Q<Label>("type");
        generatedPort.contentContainer.Remove(oldLable);

        var outputPortCount = dialogueNode.outputContainer.Query("connector").ToList().Count;
        var outputPortName = $"Choice {outputPortCount}";
        generatedPort.portName = outputPortName;

        var choicePortName = string.IsNullOrEmpty(overriddenPortName)
            ? $"Choice{outputPortCount + 1}" : overriddenPortName;

        var textField = new TextField
        {
            name = string.Empty,
            value = choicePortName
        };
        textField.RegisterValueChangedCallback(evt => generatedPort.portName = evt.newValue);
        generatedPort.contentContainer.Add(new Label(" "));
        generatedPort.contentContainer.Add(textField);
        var deleteButton = new Button(() => RemovePort(dialogueNode, generatedPort)){
            text = "x"
        };
        generatedPort.contentContainer.Add(deleteButton);

        generatedPort.portName = choicePortName;
        dialogueNode.outputContainer.Add(generatedPort);
        dialogueNode.RefreshExpandedState();
        dialogueNode.RefreshPorts();
    }

    private void RemovePort(DialogueNode dialogueNode, Port generatedPort)
    {
        var targerEdge = edges.ToList().Where(x => x.output.portName == generatedPort.portName && x.output.node == generatedPort.node);

        if (!targerEdge.Any()) return;

        var edge = targerEdge.First();
        edge.input.Disconnect(edge);
        RemoveElement(targerEdge.First());

        dialogueNode.outputContainer.Remove(generatedPort);
        dialogueNode.RefreshPorts();
        dialogueNode.RefreshExpandedState();
    }
}